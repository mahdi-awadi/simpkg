package tokenizer

// EncryptionKey Encryptor encryption key
var part1 = "$%v"
var part2 = "&R%$B_7tmyh"
var part3 = "L&vMe!qkpR"
var part4 = "kpRg2tHpGaq+u"
var encryptionKey = []byte(part1 + part2 + part3 + part4)
