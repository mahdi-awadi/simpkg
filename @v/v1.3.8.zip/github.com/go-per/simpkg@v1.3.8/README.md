# Simplified Packages
```
Includes reusable packages
``` 
