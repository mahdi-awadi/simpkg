// file name template {locale}.json like en.json, fa.json, etc.
// translations string template {"USER_NOT_FOUND": "User not found"}
// translations with argument template {"USER_NOT_FOUND": "User {name} not found"}
// translation directories
// root
// 	   |local
// 	   		 |t1.json
// 	   		 |t2.json
// 	   |local
// 	   		 |t1.json
// 	   		 |t2.json

package i18n
