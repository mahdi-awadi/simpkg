package types

// H is a map[string]any
type H map[string]any
